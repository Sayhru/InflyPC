﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management;
using OpenHardwareMonitor.Hardware;
using System.Threading.Tasks;

namespace ProjectCpuInfo
{
    internal class api
    {
        uint cachesize;
        Boolean isActive;
        string cpuTemp;
        static Computer c = new Computer() { GPUEnabled = true, CPUEnabled = true };


        public void cOpen()
        {
            c.Open();
            isActive = true;
            if (isActive == true)
            {

            } else
            {
                c.Open();
            }
        }
        public string getGpuClock()
        {
            //it will open the computer instance;

            foreach (var hardware in c.Hardware)
            {
                //Just update when he found some update;
                if (hardware.HardwareType == HardwareType.GpuNvidia)
                {

                    foreach (var sensor in hardware.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Clock)
                        {
                            hardware.Update();
                            return sensor.Value.ToString();
                        }
                    }
                } else if (hardware.HardwareType != HardwareType.GpuAti)
                {

                    foreach (var sensor in hardware.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Clock)
                        {
                            hardware.Update();
                            return sensor.Value.ToString();
                        }
                    }
                }
            }


            return "Non regonized";
        }

        public String getGpuMemory(string hwClass, String syntax)
        {
            //it will open the computer instance;

            foreach (var hardware in c.Hardware)
            {
                //Just update when he found some update;
                foreach (ISensor gpu in hardware.Sensors)
                {
                    if(gpu.Name == "GPU Memory" && gpu.Index == 1)
                    {
                        hardware.Update();
                        return gpu.Value.ToString();
                    }
                }
            }
            return "Non regozined";
        }
        public String getGpuUsage(string hwClass, String syntax)
        {
            //it will open the computer instance;
            c.Open();
            foreach (var hardware in c.Hardware)
            {

                //Just update when he found some update;
                foreach (ISensor gpu in hardware.Sensors)
                {
                    if (gpu.SensorType == SensorType.Load && gpu.Name == "GPU Core")
                    { 
                        return Convert.ToString(gpu.Value) + " %";
                    }
                }
            }
            return "Non regozined";
        }


        public String getGpuCore()
        {
            foreach (var hardware in c.Hardware)
            {

                if (hardware.HardwareType == HardwareType.GpuNvidia)
                {
                    // only fire the update when found

                    // loop through the data
                    foreach (var sensor in hardware.Sensors)
                        if (sensor.SensorType == SensorType.Temperature)
                        {
                            hardware.Update();
                            return sensor.Value.ToString();

                        }

                } else if(hardware.HardwareType == HardwareType.GpuAti)
                {

                    // loop through the data
                    foreach (var sensor in hardware.Sensors)
                        if (sensor.SensorType == SensorType.Temperature)
                        {
                            // store    
                            hardware.Update();
                            return sensor.Value.ToString();

                        }
                }
            }
            return "Non Regonized";
        }

        public String getTemperature()
        {
            foreach (IHardware hardware in c.Hardware)
            {

                foreach (ISensor sensor in hardware.Sensors)
                {
                    
                    // Celsius is default unit
                    if (sensor.SensorType == SensorType.Temperature)
                    {
                        hardware.Update();
                        return sensor.Value.ToString();
                    }

                }
            }
            return "Non Regozined";
        }

        public String getComponentString(String hwClass, String syntax)
        {

            ManagementObjectSearcher mos = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM " + hwClass);

            foreach (ManagementObject obj in mos.Get())
            {
                return "" + Convert.ToString((obj[syntax]));
            }
            return "Non recognized";
        }

        public UInt32 getComponentUint32(String hwClass, String syntax)
        {
            ManagementObjectSearcher mos = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM " + hwClass);

            foreach (ManagementObject obj in mos.Get())
            {
                return Convert.ToUInt32((obj[syntax]));
            }
            return 0;
        }

        public uint getCpuSpeed(String syntax)
        {
            using (ManagementObject Mo = new ManagementObject("Win32_Processor.DeviceID='CPU0'"))
            {
                cachesize = (uint)(Mo[syntax]);
                return cachesize;
            }
        }
    }
}
