﻿namespace ProjectCpuInfo
{
    partial class Cpu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.backgroundCpu = new System.Windows.Forms.Panel();
            this.cpuName = new MetroFramework.Controls.MetroLabel();
            this.cpuUsage = new MetroFramework.Controls.MetroLabel();
            this.cpuTemperature = new MetroFramework.Controls.MetroLabel();
            this.cpuThreads = new MetroFramework.Controls.MetroLabel();
            this.cpuCore = new MetroFramework.Controls.MetroLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cpuUsagee = new System.Diagnostics.PerformanceCounter();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.CpuCacheL3 = new MetroFramework.Controls.MetroLabel();
            this.cpuCacheL2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.cpuUsagee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.ForeColor = System.Drawing.Color.Black;
            this.metroLabel1.Location = new System.Drawing.Point(0, 88);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(217, 33);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "CPU Name:";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseCustomForeColor = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.ForeColor = System.Drawing.Color.Black;
            this.metroLabel2.Location = new System.Drawing.Point(0, 121);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(228, 33);
            this.metroLabel2.TabIndex = 1;
            this.metroLabel2.Text = "CPU Usage:";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseCustomForeColor = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.ForeColor = System.Drawing.Color.Black;
            this.metroLabel3.Location = new System.Drawing.Point(0, 154);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(254, 33);
            this.metroLabel3.TabIndex = 2;
            this.metroLabel3.Text = "CPU Temperature:";
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel3.UseCustomBackColor = true;
            this.metroLabel3.UseCustomForeColor = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.ForeColor = System.Drawing.Color.Black;
            this.metroLabel5.Location = new System.Drawing.Point(0, 190);
            this.metroLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(197, 33);
            this.metroLabel5.TabIndex = 4;
            this.metroLabel5.Text = "CPU Threads:";
            this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.UseCustomForeColor = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.ForeColor = System.Drawing.Color.Black;
            this.metroLabel6.Location = new System.Drawing.Point(0, 223);
            this.metroLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(197, 33);
            this.metroLabel6.TabIndex = 5;
            this.metroLabel6.Text = "CPU Cores:";
            this.metroLabel6.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel6.UseCustomBackColor = true;
            this.metroLabel6.UseCustomForeColor = true;
            // 
            // backgroundCpu
            // 
            this.backgroundCpu.BackColor = System.Drawing.Color.Black;
            this.backgroundCpu.Location = new System.Drawing.Point(0, 0);
            this.backgroundCpu.Name = "backgroundCpu";
            this.backgroundCpu.Size = new System.Drawing.Size(1100, 68);
            this.backgroundCpu.TabIndex = 6;
            // 
            // cpuName
            // 
            this.cpuName.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.cpuName.ForeColor = System.Drawing.Color.Black;
            this.cpuName.Location = new System.Drawing.Point(205, 88);
            this.cpuName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cpuName.Name = "cpuName";
            this.cpuName.Size = new System.Drawing.Size(490, 33);
            this.cpuName.TabIndex = 7;
            this.cpuName.Text = "Analysing...";
            this.cpuName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cpuName.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cpuName.UseCustomBackColor = true;
            this.cpuName.UseCustomForeColor = true;
            // 
            // cpuUsage
            // 
            this.cpuUsage.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.cpuUsage.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.cpuUsage.ForeColor = System.Drawing.Color.Black;
            this.cpuUsage.Location = new System.Drawing.Point(205, 121);
            this.cpuUsage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cpuUsage.Name = "cpuUsage";
            this.cpuUsage.Size = new System.Drawing.Size(232, 33);
            this.cpuUsage.TabIndex = 8;
            this.cpuUsage.Text = "Analysing...";
            this.cpuUsage.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cpuUsage.UseCustomBackColor = true;
            this.cpuUsage.UseCustomForeColor = true;
            // 
            // cpuTemperature
            // 
            this.cpuTemperature.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.cpuTemperature.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.cpuTemperature.ForeColor = System.Drawing.Color.Black;
            this.cpuTemperature.Location = new System.Drawing.Point(205, 154);
            this.cpuTemperature.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cpuTemperature.Name = "cpuTemperature";
            this.cpuTemperature.Size = new System.Drawing.Size(314, 33);
            this.cpuTemperature.TabIndex = 9;
            this.cpuTemperature.Text = "Analysing...";
            this.cpuTemperature.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cpuTemperature.UseCustomBackColor = true;
            this.cpuTemperature.UseCustomForeColor = true;
            // 
            // cpuThreads
            // 
            this.cpuThreads.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.cpuThreads.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.cpuThreads.ForeColor = System.Drawing.Color.Black;
            this.cpuThreads.Location = new System.Drawing.Point(205, 190);
            this.cpuThreads.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cpuThreads.Name = "cpuThreads";
            this.cpuThreads.Size = new System.Drawing.Size(168, 33);
            this.cpuThreads.TabIndex = 11;
            this.cpuThreads.Text = "Analysing...";
            this.cpuThreads.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cpuThreads.UseCustomBackColor = true;
            this.cpuThreads.UseCustomForeColor = true;
            // 
            // cpuCore
            // 
            this.cpuCore.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.cpuCore.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.cpuCore.ForeColor = System.Drawing.Color.Black;
            this.cpuCore.Location = new System.Drawing.Point(205, 223);
            this.cpuCore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cpuCore.Name = "cpuCore";
            this.cpuCore.Size = new System.Drawing.Size(159, 33);
            this.cpuCore.TabIndex = 12;
            this.cpuCore.Text = "Analysing...";
            this.cpuCore.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cpuCore.UseCustomBackColor = true;
            this.cpuCore.UseCustomForeColor = true;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.changeTime);
            // 
            // cpuUsagee
            // 
            this.cpuUsagee.CategoryName = "Processor";
            this.cpuUsagee.CounterName = "% Processor Time";
            this.cpuUsagee.InstanceName = "_total";
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.RoyalBlue;
            this.chart1.BorderlineColor = System.Drawing.Color.LightCoral;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(614, 71);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series1.Legend = "Legend1";
            series1.Name = "cpuUsagee";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(388, 185);
            this.chart1.TabIndex = 13;
            // 
            // metroLabel7
            // 
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.ForeColor = System.Drawing.Color.Black;
            this.metroLabel7.Location = new System.Drawing.Point(0, 256);
            this.metroLabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(197, 33);
            this.metroLabel7.TabIndex = 14;
            this.metroLabel7.Text = "CPU CacheL3:";
            this.metroLabel7.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel7.UseCustomBackColor = true;
            this.metroLabel7.UseCustomForeColor = true;
            // 
            // CpuCacheL3
            // 
            this.CpuCacheL3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.CpuCacheL3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.CpuCacheL3.ForeColor = System.Drawing.Color.Black;
            this.CpuCacheL3.Location = new System.Drawing.Point(205, 256);
            this.CpuCacheL3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CpuCacheL3.Name = "CpuCacheL3";
            this.CpuCacheL3.Size = new System.Drawing.Size(159, 33);
            this.CpuCacheL3.TabIndex = 15;
            this.CpuCacheL3.Text = "Analysing...";
            this.CpuCacheL3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.CpuCacheL3.UseCustomBackColor = true;
            this.CpuCacheL3.UseCustomForeColor = true;
            // 
            // cpuCacheL2
            // 
            this.cpuCacheL2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.cpuCacheL2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.cpuCacheL2.ForeColor = System.Drawing.Color.Black;
            this.cpuCacheL2.Location = new System.Drawing.Point(205, 289);
            this.cpuCacheL2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cpuCacheL2.Name = "cpuCacheL2";
            this.cpuCacheL2.Size = new System.Drawing.Size(159, 33);
            this.cpuCacheL2.TabIndex = 17;
            this.cpuCacheL2.Text = "Analysing...";
            this.cpuCacheL2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cpuCacheL2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cpuCacheL2.UseCustomBackColor = true;
            this.cpuCacheL2.UseCustomForeColor = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel8.ForeColor = System.Drawing.Color.Black;
            this.metroLabel8.Location = new System.Drawing.Point(0, 289);
            this.metroLabel8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(197, 33);
            this.metroLabel8.TabIndex = 16;
            this.metroLabel8.Text = "CPU CacheL2:";
            this.metroLabel8.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel8.UseCustomBackColor = true;
            this.metroLabel8.UseCustomForeColor = true;
            // 
            // Cpu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(1102, 546);
            this.Controls.Add(this.cpuCacheL2);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.CpuCacheL3);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.cpuCore);
            this.Controls.Add(this.cpuThreads);
            this.Controls.Add(this.cpuTemperature);
            this.Controls.Add(this.cpuUsage);
            this.Controls.Add(this.cpuName);
            this.Controls.Add(this.backgroundCpu);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Cpu";
            this.Text = "Cpu";
            this.Load += new System.EventHandler(this.Cpu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cpuUsagee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.Panel backgroundCpu;
        private MetroFramework.Controls.MetroLabel cpuName;
        private MetroFramework.Controls.MetroLabel cpuUsage;
        private MetroFramework.Controls.MetroLabel cpuTemperature;
        private MetroFramework.Controls.MetroLabel cpuThreads;
        private MetroFramework.Controls.MetroLabel cpuCore;
        private System.Windows.Forms.Timer timer1;
        private System.Diagnostics.PerformanceCounter cpuUsagee;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel CpuCacheL3;
        private MetroFramework.Controls.MetroLabel cpuCacheL2;
        private MetroFramework.Controls.MetroLabel metroLabel8;
    }
}