﻿namespace ProjectCpuInfo
{
    partial class Gpu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.backgroundCpu = new System.Windows.Forms.Panel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.gpuName = new MetroFramework.Controls.MetroLabel();
            this.gpuUsage = new MetroFramework.Controls.MetroLabel();
            this.gpuMemory = new MetroFramework.Controls.MetroLabel();
            this.gpuTemperature = new MetroFramework.Controls.MetroLabel();
            this.gpuClock = new MetroFramework.Controls.MetroLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // backgroundCpu
            // 
            this.backgroundCpu.BackColor = System.Drawing.Color.Black;
            this.backgroundCpu.Location = new System.Drawing.Point(-5, -6);
            this.backgroundCpu.Name = "backgroundCpu";
            this.backgroundCpu.Size = new System.Drawing.Size(1117, 75);
            this.backgroundCpu.TabIndex = 7;
            // 
            // metroLabel1
            // 
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.ForeColor = System.Drawing.Color.AliceBlue;
            this.metroLabel1.Location = new System.Drawing.Point(12, 106);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(361, 25);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "GPU Name:";
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseCustomForeColor = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.ForeColor = System.Drawing.Color.AliceBlue;
            this.metroLabel2.Location = new System.Drawing.Point(12, 140);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(377, 25);
            this.metroLabel2.TabIndex = 8;
            this.metroLabel2.Text = "GPU Usage:";
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseCustomForeColor = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.ForeColor = System.Drawing.Color.AliceBlue;
            this.metroLabel3.Location = new System.Drawing.Point(12, 175);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(361, 35);
            this.metroLabel3.TabIndex = 9;
            this.metroLabel3.Text = "GPU Memory Clock:";
            this.metroLabel3.UseCustomBackColor = true;
            this.metroLabel3.UseCustomForeColor = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.ForeColor = System.Drawing.Color.AliceBlue;
            this.metroLabel4.Location = new System.Drawing.Point(12, 210);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(254, 34);
            this.metroLabel4.TabIndex = 10;
            this.metroLabel4.Text = "GPU Temperature:";
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseCustomForeColor = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.ForeColor = System.Drawing.Color.AliceBlue;
            this.metroLabel7.Location = new System.Drawing.Point(12, 244);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(377, 25);
            this.metroLabel7.TabIndex = 13;
            this.metroLabel7.Text = "GPU Clock:";
            this.metroLabel7.UseCustomBackColor = true;
            this.metroLabel7.UseCustomForeColor = true;
            // 
            // gpuName
            // 
            this.gpuName.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.gpuName.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.gpuName.ForeColor = System.Drawing.Color.AliceBlue;
            this.gpuName.Location = new System.Drawing.Point(424, 106);
            this.gpuName.Name = "gpuName";
            this.gpuName.Size = new System.Drawing.Size(335, 25);
            this.gpuName.TabIndex = 14;
            this.gpuName.Text = "Analysing...";
            this.gpuName.UseCustomBackColor = true;
            this.gpuName.UseCustomForeColor = true;
            // 
            // gpuUsage
            // 
            this.gpuUsage.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.gpuUsage.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.gpuUsage.ForeColor = System.Drawing.Color.AliceBlue;
            this.gpuUsage.Location = new System.Drawing.Point(424, 140);
            this.gpuUsage.Name = "gpuUsage";
            this.gpuUsage.Size = new System.Drawing.Size(335, 25);
            this.gpuUsage.TabIndex = 15;
            this.gpuUsage.Text = "Analysing...";
            this.gpuUsage.UseCustomBackColor = true;
            this.gpuUsage.UseCustomForeColor = true;
            // 
            // gpuMemory
            // 
            this.gpuMemory.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.gpuMemory.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.gpuMemory.ForeColor = System.Drawing.Color.AliceBlue;
            this.gpuMemory.Location = new System.Drawing.Point(424, 175);
            this.gpuMemory.Name = "gpuMemory";
            this.gpuMemory.Size = new System.Drawing.Size(335, 25);
            this.gpuMemory.TabIndex = 16;
            this.gpuMemory.Text = "Analysing...";
            this.gpuMemory.UseCustomBackColor = true;
            this.gpuMemory.UseCustomForeColor = true;
            // 
            // gpuTemperature
            // 
            this.gpuTemperature.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.gpuTemperature.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.gpuTemperature.ForeColor = System.Drawing.Color.AliceBlue;
            this.gpuTemperature.Location = new System.Drawing.Point(424, 210);
            this.gpuTemperature.Name = "gpuTemperature";
            this.gpuTemperature.Size = new System.Drawing.Size(335, 25);
            this.gpuTemperature.TabIndex = 17;
            this.gpuTemperature.Text = "Analysing...";
            this.gpuTemperature.UseCustomBackColor = true;
            this.gpuTemperature.UseCustomForeColor = true;
            // 
            // gpuClock
            // 
            this.gpuClock.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.gpuClock.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.gpuClock.ForeColor = System.Drawing.Color.AliceBlue;
            this.gpuClock.Location = new System.Drawing.Point(424, 244);
            this.gpuClock.Name = "gpuClock";
            this.gpuClock.Size = new System.Drawing.Size(335, 25);
            this.gpuClock.TabIndex = 20;
            this.gpuClock.Text = "Analysing...";
            this.gpuClock.UseCustomBackColor = true;
            this.gpuClock.UseCustomForeColor = true;
            this.gpuClock.Click += new System.EventHandler(this.gpuClock_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1500;
            this.timer1.Tick += new System.EventHandler(this.changeTime);
            // 
            // Gpu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(1084, 499);
            this.Controls.Add(this.gpuClock);
            this.Controls.Add(this.gpuTemperature);
            this.Controls.Add(this.gpuMemory);
            this.Controls.Add(this.gpuUsage);
            this.Controls.Add(this.gpuName);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.backgroundCpu);
            this.ForeColor = System.Drawing.Color.RoyalBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Gpu";
            this.Text = "Gpu";
            this.Load += new System.EventHandler(this.Gpu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel backgroundCpu;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel gpuName;
        private MetroFramework.Controls.MetroLabel gpuUsage;
        private MetroFramework.Controls.MetroLabel gpuMemory;
        private MetroFramework.Controls.MetroLabel gpuTemperature;
        private MetroFramework.Controls.MetroLabel gpuClock;
        private System.Windows.Forms.Timer timer1;
    }
}