﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectCpuInfo
{
    public partial class Gpu : Form
    {
        api a1 = new api();
        public Gpu()
        {
            InitializeComponent();
        }

        private void Gpu_Load(object sender, EventArgs e)
        {
                backgroundCpu.BackColor = Color.FromArgb(100,0,0,0);
            a1.cOpen();
        }

        private void changeTime(object sender, EventArgs e)
        {
            a1.cOpen();
            this.gpuName.Text = a1.getComponentString("Win32_VideoController", "Name");
            this.gpuTemperature.Text = a1.getGpuCore();
            this.gpuClock.Text = a1.getGpuClock();
            this.gpuMemory.Text = a1.getGpuMemory("Win32_VideoController", "MaxNumberControlled");
            this.gpuUsage.Text = a1.getGpuUsage("a", "a");

        }


        private void gpuClock_Click(object sender, EventArgs e)
        {

        }
    }
}
