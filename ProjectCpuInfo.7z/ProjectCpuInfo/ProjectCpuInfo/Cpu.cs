﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectCpuInfo
{
    public partial class Cpu : Form
    {
        api a = new api();
        public Cpu()
        {
            InitializeComponent();
        }

        private void Cpu_Load(object sender, EventArgs e)
        {
            api a = new api();
            this.backgroundCpu.BackColor = Color.FromArgb(100, 0, 0, 0);
            this.cpuName.Text = a.getComponentString("Win32_Processor", "Name");
            this.cpuThreads.Text = Convert.ToString(a.getComponentUint32("Win32_Processor", "ThreadCount"));
            this.cpuCore.Text = Convert.ToString(a.getComponentUint32("Win32_Processor", "NumberOfCores"));
            this.CpuCacheL3.Text = Convert.ToString(a.getCpuSpeed("L3CacheSize")) + " MB";
            this.cpuCacheL2.Text = Convert.ToString(a.getCpuSpeed("L2CacheSize")) + " MB";
        }

        private void changeTime(object sender, EventArgs e)
        {
            //Melhorar metodo de temperature da cpu
            a.cOpen();
            this.cpuTemperature.Text = a.getTemperature();
            this.cpuUsage.Text = cpuUsagee.NextValue() + " %";
            chart1.Series["cpuUsagee"].Points.AddY(cpuUsagee.NextValue());
        }
    }
}
