﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectCpuInfo
{
    public partial class Form1 : Form
    {
        Cpu cpu;
        public Form1()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Cpu a = new Cpu();
            guna2Panel1.Controls.Clear();
            a.TopLevel = false;
            guna2Panel1.Controls.Add(a);
            a.Show();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Gpu a = new Gpu();
            guna2Panel1.Controls.Clear();
            a.TopLevel = false;
            guna2Panel1.Controls.Add(a);
            a.Show();
        }
    }
}
